.. Similarity Plugin documentation master file, created by
   sphinx-quickstart on Fri Jun 19 19:52:50 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Similarity Plugin's documentation!
=============================================

.. toctree::
   :maxdepth: 4

   concept
   tutorial
   dialog_classes
   about
