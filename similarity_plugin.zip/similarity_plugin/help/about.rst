=====================
About Plugin
=====================

Plugin created by Pandu Wicaksono and Takdir. There is no external library included in this plugin except **PyQGIS**. Similarity score implementing **GOF Mapcurves** method (Hargrove et. al. (2006) `<doi:10.1007/s10109-006-0025-x>`_ ). Further information you can contact us at email panickspa@gmail.com.

.. _<doi:10.1007/s10109-006-0025-x>: https://doi.org/10.1007/s10109-006-0025-x