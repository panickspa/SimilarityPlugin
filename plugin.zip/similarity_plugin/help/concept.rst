==================
Concept Algorithm
==================

This plugin has four concept there are Mapcurves, Squential, Nearest Neighbour, and Wilkersat. Mapcurves method is used for similarity calculation. The other method is used for searching the matching feature on layer. User determine the treshold of similarity to make sure the map is similar in some confidence interval.

Mapcurves (Hargrove et al. 2006)
-------------------------------
Mapcurvess is algorithm for checking similarity between two maps. Mapcurves Algorithm is developed by Hargrove et al. (2006). Mapcurvess can calculate the similarity proportion. Mapcurves can be applied in vector maps. 

.. image:: ./gof.png
    :width: 233
    
Squential
-------------------------------
Squential Method will checking the features in layer within each bounding box (bb) features. 

.. image:: ./squential.png
    :width: 400


Nearest Neighbour
-------------------------------
Nearest Neighbour Method will checking the features in layer within determined box. Box will contructed in a radius. Radius is determined by user.

.. image:: ./nn.png
    :width: 400

The geometry feature will translated to the center of neighbour before calculating the similarity score.

Wilkerstat
-------------------------------
Wilkerstat Method depends on database system in BPS. The method is matching the primary keys. The keys are PROVNO, KABKOTNO, KECNO, DESANO (see https://sig.bps.go.id/)